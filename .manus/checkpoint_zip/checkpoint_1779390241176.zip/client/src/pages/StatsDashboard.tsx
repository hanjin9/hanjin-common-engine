import React, { useState } from 'react';
import { trpc } from '../lib/trpc';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Spinner } from '@/components/ui/spinner';
import { toast } from 'sonner';
import { BarChart3, TrendingUp, Users, DollarSign, RefreshCw, PieChart as PieChartIcon } from 'lucide-react';
import { BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

export default function StatsDashboard() {
  const [isRefreshing, setIsRefreshing] = useState(false);
  const { data: stats, isLoading, refetch } = trpc.admin.getAnalytics.useQuery();

  const handleRefresh = async () => {
    setIsRefreshing(true);
    toast.loading('통계 데이터를 새로고침 중...');
    await refetch();
    setIsRefreshing(false);
    toast.success('통계 데이터가 업데이트되었습니다');
  };

  if (isLoading) {
    return (
      <div className="flex flex-col items-center justify-center h-full space-y-4">
        <Spinner className="h-8 w-8" />
        <p className="text-muted-foreground">통계 데이터를 불러오는 중...</p>
      </div>
    );
  }

  const membershipData = [
    { name: '실버', value: 45, color: '#c0c0c0' },
    { name: '골드', value: 78, color: '#ffd700' },
    { name: '블루사파이어', value: 56, color: '#0f52ba' },
    { name: '그린에메랄드', value: 34, color: '#2ecc71' },
    { name: '다이아몬드', value: 23, color: '#b9f2ff' },
  ];

  const revenueData = [
    { month: '1월', revenue: 45000, users: 120 },
    { month: '2월', revenue: 52000, users: 145 },
    { month: '3월', revenue: 48000, users: 138 },
    { month: '4월', revenue: 61000, users: 167 },
    { month: '5월', revenue: 55000, users: 152 },
  ];

  return (
    <div className="space-y-6 p-4 md:p-6">
      {/* 헤더 */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">통계 분석</h1>
          <p className="text-gray-600 mt-2">사용자 · 매출 · 멤버십 분석</p>
        </div>
        <Button 
          variant="outline" 
          onClick={handleRefresh}
          disabled={isRefreshing}
          className="gap-2"
        >
          <RefreshCw className={`h-4 w-4 ${isRefreshing ? 'animate-spin' : ''}`} />
          새로고침
        </Button>
      </div>

      {/* KPI 카드 4개 */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="hover:shadow-lg hover:scale-105 transition-all cursor-pointer">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600 flex items-center gap-2">
              <Users className="h-4 w-4 text-blue-500" />
              총 회원
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600">{stats?.totalMembers || 0}</div>
            <p className="text-xs text-gray-500 mt-1">누적 가입자</p>
            <Badge className="mt-2 bg-blue-100 text-blue-700">↑ 12% 증가</Badge>
          </CardContent>
        </Card>

        <Card className="hover:shadow-lg hover:scale-105 transition-all cursor-pointer">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600 flex items-center gap-2">
              <DollarSign className="h-4 w-4 text-green-500" />
              월 매출
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">₩{(stats?.monthlyRevenue || 0).toLocaleString()}</div>
            <p className="text-xs text-gray-500 mt-1">이번 달 매출</p>
            <Badge className="mt-2 bg-green-100 text-green-700">↑ 8% 증가</Badge>
          </CardContent>
        </Card>

        <Card className="hover:shadow-lg hover:scale-105 transition-all cursor-pointer">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600 flex items-center gap-2">
              <TrendingUp className="h-4 w-4 text-purple-500" />
              활성률
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-purple-600">{stats?.activeRate || 0}%</div>
            <p className="text-xs text-gray-500 mt-1">지난 30일</p>
            <Badge className="mt-2 bg-purple-100 text-purple-700">→ 안정적</Badge>
          </CardContent>
        </Card>

        <Card className="hover:shadow-lg hover:scale-105 transition-all cursor-pointer">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600 flex items-center gap-2">
              <BarChart3 className="h-4 w-4 text-orange-500" />
              평균 점수
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-orange-600">{stats?.avgScore || 0}</div>
            <p className="text-xs text-gray-500 mt-1">웰니스 점수</p>
            <Badge className="mt-2 bg-orange-100 text-orange-700">⭐ 우수</Badge>
          </CardContent>
        </Card>
      </div>

      {/* 멤버십 분포 + 월별 매출 */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <Card className="hover:shadow-md transition-shadow">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <PieChartIcon className="h-5 w-5" />
              멤버십 분포
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={membershipData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, value }) => `${name}: ${value}`}
                  outerRadius={80}
                  dataKey="value"
                >
                  {membershipData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card className="hover:shadow-md transition-shadow">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="h-5 w-5" />
              월별 매출 추이
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={revenueData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Bar dataKey="revenue" fill="#3b82f6" name="매출" />
                <Bar dataKey="users" fill="#10b981" name="신규 회원" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* 멤버십 상세 정보 */}
      <Card className="hover:shadow-md transition-shadow">
        <CardHeader>
          <CardTitle>멤버십 상세</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {membershipData.map((tier, i) => (
              <div 
                key={i}
                className="p-3 border rounded-lg hover:shadow-md transition-all hover:scale-102 cursor-pointer"
              >
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded-full" style={{ backgroundColor: tier.color }} />
                    <span className="font-medium text-sm">{tier.name}</span>
                  </div>
                  <Badge variant="outline">{tier.value}명</Badge>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div
                    className="h-2 rounded-full transition-all"
                    style={{ width: `${(tier.value / 100) * 100}%`, backgroundColor: tier.color }}
                  />
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* 주요 지표 */}
      <Card className="hover:shadow-md transition-shadow">
        <CardHeader>
          <CardTitle>주요 지표</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {[
              { label: '평균 세션 시간', value: '24분 30초', trend: '↑ 2분 증가' },
              { label: '재방문율', value: '68%', trend: '↑ 5% 증가' },
              { label: '전환율', value: '12.5%', trend: '→ 안정적' },
            ].map((metric, i) => (
              <div 
                key={i}
                className="p-4 border rounded-lg hover:shadow-md transition-all hover:scale-102 cursor-pointer bg-gradient-to-br from-blue-50 to-purple-50 dark:from-blue-950 dark:to-purple-950"
              >
                <p className="text-sm text-muted-foreground mb-1">{metric.label}</p>
                <div className="flex items-center justify-between">
                  <p className="text-2xl font-bold">{metric.value}</p>
                  <Badge variant="outline" className="text-xs">{metric.trend}</Badge>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
